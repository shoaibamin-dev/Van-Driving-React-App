import React, { useState, useEffect, useRef } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter
} from '@coreui/react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Col, Row, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

import axios from 'axios';

import { database } from '../../firebase'


// import usersData from './UsersData'

const getBadge = status => {
  switch (status) {
    case 'Active': return 'success'
    case 'Inactive': return 'danger'
    case 'Pending': return 'warning'
    case 'Banned': return 'danger'
    case 'View': return 'primary'
    default: return 'primary'
  }
}

const Add = (props) => {
  const [values, setValues] = props.handles;
  const {
    buttonLabel,
    className,
    addForm,
    modal,
    toggle
  } = props;
  const [children, setChildren] = useState([]);
  const [parents, setParents] = useState([]);

  const getParents = async () => {

    const childRef = await database.ref('parents');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localUsers = Object.entries(snap.val())
      console.log(localUsers)
      setParents(localUsers.map(child => child[1]))
    })

  }
  const getChildren = async () => {
    const childRef = await database.ref('children');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localUsers = Object.entries(snap.val())
      console.log(localUsers)
      setChildren(localUsers.map(child => child[1]))
    })
  }

  useEffect(() => {

    getParents();
    getChildren();


  }, [])


  return (
    <div>
      <Button style={{ float: 'right' }} color="primary" onClick={toggle}>{buttonLabel}</Button>
      <Modal isOpen={modal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Assign Children To Parent</ModalHeader>
        <ModalBody>

          <Form onSubmit={addForm}>
            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Child ID</Label>
              <Col sm={10}>

                <Input type="select" name="selectChildID" onChange={(ev) => setValues({ ...values, child_id: ev.target.value })}>
                  <option value="">SELECT CHILD ID</option>
                  {children.map((child, idx) => <option key={idx} value={child.id}>{child.id} - {child.name}</option>)}
                </Input>

              </Col>
            </FormGroup>

            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Parent ID</Label>
              <Col sm={10}>

                <Input type="select" name="selectParentID" onChange={(ev) => setValues({ ...values, parent_id: ev.target.value })}>
                  <option value="">SELECT PARENT ID</option>
                  {parents.map((parent, idx) => <option key={idx} value={parent.id}>{parent.id} - {parent.name}</option>)}
                </Input>

              </Col>
            </FormGroup>


            <FormGroup check row>
              <Col sm={{ size: 10, offset: 2 }}>
                <Button color="success" style={{ float: 'right' }}>Submit</Button>
              </Col>
            </FormGroup>
          </Form>

        </ModalBody>
        <ModalFooter>
          {/* <Button color="primary" onClick={toggle}>Do Something</Button>{' '} */}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}



const Users = () => {
  const history = useHistory()
  const queryPage = useLocation().search.match(/page=([0-9]+)/, '')
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1)
  const [page, setPage] = useState(currentPage)
  const [userData, setUserData] = useState([])
  const [editColumn, setEditColumn] = useState('');
  // const [editValues, setEditValues]

  const [values, setValues] = useState({
    parent_id: '', child_id: ''
  });

  const [children, setChildren] = useState([]);
  const [localValues, setLocalValues] = useState('')
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);

  const pageChange = newPage => {
    currentPage !== newPage && history.push(`/users?page=${newPage}`)
  }

  useEffect(() => {
    currentPage !== page && setPage(currentPage)
  }, [currentPage, page])

  useEffect(() => {

    if (!localStorage.getItem('admin-login')) {
      return history.push('/')
    }

    const childRef = database.ref('parent_child');
    const parentRef = database.ref('parents');
    childRef.once('value', snap => {
      if (!snap.val()) return;
      const localChildren = Object.entries(snap.val())
      console.log(localChildren)


      const results = combineData(localChildren);

      results.then(data => setChildren(data))




    })

  }, [])

  const combineData = async (localChildren) => {

    const parentRef = database.ref('parents');
    const childRef = database.ref('children');

    var results = await Promise.all(localChildren.map(async (child) => {

      let currentChild = { ...child[1] }
      console.log(currentChild.parent_id)

      await parentRef.child(currentChild.parent_id).once('value', snap2 => {
        if (!snap2.val()) return
        const currentParent = snap2.val();
        currentChild.parent_name = currentParent["name"];

      });

      await childRef.child(currentChild.child_id).once('value', snap2 => {
        if (!snap2.val()) return
        const currentParent = snap2.val();
        currentChild.child_name = currentParent["name"];

      });


      return currentChild;

    }));
    console.log("Results", results)
    return results;

  }

  const addForm = (ev) => {
    ev.preventDefault();
    console.log(values)

    const childRef = database.ref('parent_child');
    const key = childRef.push().key;
    childRef.child(key).set({ ...values, id: key, created_at: new Date().toLocaleString(), is_active: true })
      .then(() => {
        alert('Child assigned to parent successfully.')
        toggle();
      })
      .catch(() => alert('Something went wrong, please try again!'))

  }

  const editForm = () => {


    const childRef = database.ref('parent_child').child(editColumn);
    childRef.update({
      ...localValues
    })
      .then(() => {
        alert('parent_child updated successfully.')
        setChildren(children.map(child => child.id === editColumn ? { ...child, ...localValues } : child))
        setEditColumn('')
        setLocalValues('')
      })
      .catch(error => alert('Something went wrong.'))




  }

  const deleteForm = (id) => {

    const childRef = database.ref('parent_child').child(id);
    childRef.update({
      is_active: false
    })
      .then(() => {
        alert('The selected record is deleted successfully.')
      })
      .catch(error => alert('Something went wrong.'))


  }

  const undeleteForm = (id) => {

    const driverRef = database.ref('parent_child').child(id);
    driverRef.update({
      is_active: true
    })
      .then(() => {
        alert('The selected record is active!')
      })
      .catch(error => alert('Something went wrong.'))


  }



  return (
    <CRow>

      <CCol xl={12}>
        <CCard>
          <CCardHeader>
            Users
            <small className="text-muted"> Van Tracking System</small>
            <Add modal={modal} toggle={toggle} addForm={addForm} buttonLabel='Assign' handles={[values, setValues]} />
          </CCardHeader>
          <CCardBody>
            <CDataTable
              items={children}
              tableFilter
              columnFilter

              fields={[
                { key: 'id', _classes: 'font-weight-bold' },
                'parent_id',
                'parent_name',
                'child_id',
                'child_name',
                'created_at', 'is_active',
                'delete'
              ]}
              sorter
              border
              hover
              striped
              itemsPerPage={8}
              activePage={page}
              clickableRows
              column-filter
              table-filter
              scopedSlots={{




                'delete':
                  (item) => (

                    <td>
                      {
                        item.is_active ?
                          <CButton color="danger" onClick={() => {
                            deleteForm(item.id)
                          }}>Delete</CButton>
                          :
                          <CButton color="success" onClick={() => {
                            undeleteForm(item.id)
                          }}>Active</CButton>
                      }

                    </td>
                  ),
                'is_active':
                  (item) => (

                    <td>


                      <b>{item.is_active ? 'Yes' : 'No'}</b>


                    </td>
                  )




              }}
            />
            <CPagination
              activePage={page}
              onActivePageChange={pageChange}
              doubleArrows={true}
              align="center"
            />
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Users
