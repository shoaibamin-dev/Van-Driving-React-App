import React, { useState, useEffect, useRef } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter
} from '@coreui/react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Col, Row, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

import axios from 'axios';

import { database } from '../../firebase'


// import usersData from './UsersData'

const getBadge = status => {
  switch (status) {
    case 'Active': return 'success'
    case 'Inactive': return 'danger'
    case 'Pending': return 'warning'
    case 'Banned': return 'danger'
    case 'View': return 'primary'
    default: return 'primary'
  }
}

const Add = (props) => {
  const [values, setValues] = props.handles;
  const {
    buttonLabel,
    className,
    addForm
  } = props;

  const [driverChildren, setdriverChildren] = useState([]);

  const getDriverChildren = async () => {

    const childRef = await database.ref('driver_child');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localUsers = Object.entries(snap.val())
      console.log(localUsers)
      setdriverChildren(localUsers.map(child => child[1]))
    })

  }

  useEffect(() => {

    getDriverChildren();

  }, [])

  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);

  return (
    <div>
      <Button style={{ float: 'right' }} color="primary" onClick={toggle}>{buttonLabel}</Button>
      <Modal isOpen={modal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Add Parent</ModalHeader>
        <ModalBody>

          <Form onSubmit={addForm}>

            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Driver Child ID</Label>
              <Col sm={10}>

                <Input type="select" name="selectChildID" onChange={(ev) => setValues({ ...values, driver_child_id: ev.target.value })}>
                  <option value="">SELECT DRIVER CHILD ID</option>
                  {driverChildren.map((child, idx) => <option key={idx} value={child.id}>{child.id}</option>)}
                </Input>

              </Col>
            </FormGroup>


            <FormGroup row>
              <Label for="number" sm={2}>Amount (Per Month)</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, amount: ev.target.value })} type="number" name="amount" id="number" placeholder="9000" />
              </Col>
            </FormGroup>

            <FormGroup row>
              <Label for="submiDate" sm={2}>Submit Date</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({
                  ...values, submit_date: (new Date(ev.target.value).getDate()) + '/'
                    + (new Date(ev.target.value).getMonth() + 1) + '/' + (new Date(ev.target.value).getFullYear())
                })}
                  type="date" name="submiDate" id="submiDate" placeholder="10/7/2021" />
              </Col>
            </FormGroup>

            <FormGroup row>
              <Label for="startDate" sm={2}>Start Date</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({
                  ...values, start_date: (new Date(ev.target.value).getDate()) + '/'
                    + (new Date(ev.target.value).getMonth() + 1) + '/' + (new Date(ev.target.value).getFullYear())
                })}
                  type="date" name="startDate" id="startDate" placeholder="10/7/2021" />
              </Col>
            </FormGroup>

            <FormGroup row>
              <Label for="endDate" sm={2}>End Date</Label>
              <Col sm={10}>
                <Input
                  onChange={
                    (ev) => setValues({
                      ...values, end_date: (new Date(ev.target.value).getDate()) + '/'
                        + (new Date(ev.target.value).getMonth() + 1) + '/' + (new Date(ev.target.value).getFullYear())
                    })}
                  type="date" name="endDate" id="endDate" placeholder="10/7/2021" />
              </Col>
            </FormGroup>


            <FormGroup check row>
              <Col sm={{ size: 10, offset: 2 }}>
                <Button color="success" style={{ float: 'right' }}>Submit</Button>
              </Col>
            </FormGroup>
          </Form>

        </ModalBody>
        <ModalFooter>
          {/* <Button color="primary" onClick={toggle}>Do Something</Button>{' '} */}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}


const Users = () => {
  const history = useHistory()
  const queryPage = useLocation().search.match(/page=([0-9]+)/, '')
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1)
  const [page, setPage] = useState(currentPage)
  const [userData, setUserData] = useState([])
  const [editColumn, setEditColumn] = useState('');
  // const [editValues, setEditValues]

  const [values, setValues] = useState({ driver_child_id: '', submit_date: '', amount: '', start_date: '', end_date: '' });

  const [parents, setParents] = useState([]);
  const [localValues, setLocalValues] = useState('')


  const pageChange = newPage => {
    currentPage !== newPage && history.push(`/users?page=${newPage}`)
  }

  useEffect(() => {
    currentPage !== page && setPage(currentPage)
  }, [currentPage, page])

  useEffect(() => {

    if (!localStorage.getItem('admin-login')) {
      return history.push('/')
    }

    const parentRef = database.ref('driverlocation');
    parentRef.once('value', snap => {
      if (!snap.val()) return;
      const localParents = Object.entries(snap.val())


      console.log(localParents);

      setParents(localParents.map(parent => parent[1]))
    })

  }, [])

  const addForm = (ev) => {
    ev.preventDefault();
    console.log(values)

    const parentRef = database.ref('driver-parent-log');
    const key = parentRef.push().key;
    parentRef.child(key).set({ ...values, id: key, created_at: new Date().toLocaleString(), is_active: true })
      .then(() => alert('Fee Log added successfully'))
      .catch(() => alert('Something went wrong, please try again!'))

  }

  
  const editForm = () => {


    const parentRef = database.ref('driver-parent-log').child(editColumn);
    parentRef.update({
      ...localValues
    })
      .then(() => {
        alert('driver-parent-log updated successfully.')
        setParents(parents.map(parent => parent.id === editColumn ? { ...parent, ...localValues } : parent))
        setEditColumn('')
        setLocalValues('')
      })
      .catch(error => alert('Something went wrong.'))




  }

  const deleteForm = (id) => {

    const parentRef = database.ref('driver-parent-log').child(id);
    parentRef.update({
      is_active: false
    })
      .then(() => {
        alert('driver-parent-log deleted successfully.')
      })
      .catch(error => alert('Something went wrong.'))


  }


  return (
    <CRow>

      <CCol xl={12}>
        <CCard>
          <CCardHeader>
            Users
            <small className="text-muted"> Van Tracking System</small>
            {/* <Add addForm={addForm} buttonLabel='Add' handles={[values, setValues]} /> */}
          </CCardHeader>
          <CCardBody>
            <CDataTable
              items={parents}
              tableFilter
              columnFilter

              fields={[
                'driverID',
                { key: 'name', _classes: 'font-weight-bold' },
                , 'latitude', 'longitude', 'created_at'
              ]}



              sorter
              border
              hover
              striped
              itemsPerPage={8}
              activePage={page}
              clickableRows
              column-filter
              table-filter
              scopedSlots={{



                'name':
                  (item) => (

                    <td style={{ minWidth: '150px', fontWeight: 'bold' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.name
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, name: ev.target.value })}
                          value={localValues.name}
                          type="text" name="Name" placeholder="John Doe" />

                      }

                    </td>
                  ),
                'email':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.email
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, email: ev.target.value })}
                          value={localValues.email}
                          type="email" name="Email" placeholder="abc@xyz.com" />

                      }

                    </td>
                  ),
                'password':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {

                        (editColumn !== item.id)
                        &&
                        item.password
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, password: ev.target.value })}
                          value={localValues.password}
                          type="text" name="Password" placeholder="password" />

                      }

                    </td>
                  ),

                'phone':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.phone
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, phone: ev.target.value })}
                          value={localValues.phone}
                          type="tel" name="Phone" placeholder="012312312" />

                      }

                    </td>
                  ),

                'address':
                  (item) => (

                    <td style={{ minWidth: '250px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.address
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, address: ev.target.value })}
                          value={localValues.address}
                          type="text" name="Address" placeholder="ABC St" />

                      }

                    </td>
                  ),



                'lat':
                  (item) => (

                    <td style={{ minWidth: '100px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.lat
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, lat: ev.target.value })}
                          value={localValues.lat}
                          type="text" name="Latitude" placeholder="0.2332" />

                      }

                    </td>
                  ),

                'lng':
                  (item) => (

                    <td style={{ minWidth: '100px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.lng
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, lng: ev.target.value })}
                          value={localValues.lng}
                          type="text" name="Longitude" placeholder="0.2332" />

                      }

                    </td>
                  ),

                'edit':
                  (item) => (

                    <td>

                      {(editColumn !== item.id)
                        &&
                        <CButton color="primary" onClick={() => {
                          setEditColumn(item.id)
                          setLocalValues({ ...item })
                        }
                        }>
                          Edit
                        </CButton>
                        ||
                        <CButton color="success" onClick={() => {
                          editForm();
                        }}>
                          Done
                        </CButton>
                      }

                    </td>
                  ),

                'delete':
                  (item) => (

                    <td>

                      <CButton color="danger" onClick={() => {
                        deleteForm(item.id)
                      }}>Delete</CButton>


                    </td>
                  ),
                'is_active':
                  (item) => (

                    <td>


                      <b>{item.is_active ? 'Yes' : 'No'}</b>


                    </td>
                  )




              }}
            />
            <CPagination
              activePage={page}
              onActivePageChange={pageChange}
              doubleArrows={true}
              align="center"
            />
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Users
