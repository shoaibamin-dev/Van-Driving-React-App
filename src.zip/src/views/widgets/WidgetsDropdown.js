import React, { useState, useEffect } from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'


import CIcon from '@coreui/icons-react'

import axios from 'axios'

import { database } from '../../firebase'


import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'


const WidgetsDropdown = () => {

  const [values, setValues] = useState({
    drivers: 0,
    parents: 0,
    children: 0,

  })


  useEffect(async () => {

    const localState = {
      drivers: 0,
      parents: 0,
      children: 0,

    }

    const parentRef = database.ref('parents');
    await parentRef.once('value', snap => {
      if (!snap.val()) return;
      const localParents = Object.entries(snap.val())
      localState.parents = localParents.length;
    })

    const childRef = database.ref('children');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localChildren = Object.entries(snap.val())
      localState.children = localChildren.length;
  
    })

    const driverRef = database.ref('drivers');
    await driverRef.once('value', snap => {
      if (!snap.val()) return;
      const localDrivers = Object.entries(snap.val())
      localState.drivers = localDrivers.length;

    })

    setValues({ ...localState })



  }, [])



  // render
  return (
    <CRow>



      <CCol sm="6" lg="3">
        <CWidgetDropdown
          color="gradient-info"
          header={values.parents.toString()}
          text="Total Parents"
          footerSlot={
            <ChartLineSimple
              pointed
              className="mt-3 mx-3"
              style={{ height: '70px' }}
              dataPoints={[1, 18, 9, 17, 34, 22, 11]}
              pointHoverBackgroundColor="info"
              options={{ elements: { line: { tension: 0.00001 } } }}
              label="Parents"
              labels="parents"
            />
          }
        >

        </CWidgetDropdown>
      </CCol>

      <CCol sm="6" lg="3">
        <CWidgetDropdown
          color="gradient-warning"
          header={values.drivers.toString()}
          text="Total Drivers"
          footerSlot={
            <ChartLineSimple
              className="mt-3"
              style={{ height: '70px' }}
              backgroundColor="rgba(255,255,255,.2)"
              dataPoints={[78, 81, 80, 45, 34, 12, 40]}
              options={{ elements: { line: { borderWidth: 2.5 } } }}
              pointHoverBackgroundColor="warning"
              label="Drivers"
              labels="drivers"
            />
          }
        >
        </CWidgetDropdown>
      </CCol>

      <CCol sm="6" lg="3">
        <CWidgetDropdown
          color="gradient-danger"
          header={values.children.toString()}
          text="Total Children"
          footerSlot={
            <ChartBarSimple
              className="mt-3 mx-3"
              style={{ height: '70px' }}
              backgroundColor="rgb(250, 152, 152)"
              label="Children"
              labels="children"
            />
          }
        >
        </CWidgetDropdown>
      </CCol>



    </CRow>
  )
}

export default WidgetsDropdown
