import React, { useState, useEffect } from 'react'
import { Link, useHistory } from 'react-router-dom'
import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CInputGroupPrepend,
  CInputGroupText,
  CRow
} from '@coreui/react'
import CIcon from '@coreui/icons-react'

import { database } from '../../../firebase'

import axios from 'axios'

const Login = (props) => {

  // console.log(props)

  let history = useHistory();

  const [values, setValues] = useState('');


  useEffect(() =>
    
    localStorage.removeItem('admin-login')

    , [])

  const submit = () => {

    // console.log(values)

    if (values == '') {
      return alert('Empty fields')
    }

    const adminRef = database.ref('admin')
    adminRef.once('value', snapshot => {
      const snap = snapshot.val();
      if (snap["username"] === values.username && snap["password"] === values.password) {
        localStorage.setItem("admin-login", "ok")
        return history.push("/dashboard")
      }
      return alert('Invalid credentials')

    })


    // axios.post('/api/admin/login', values)
    //   .then(result => {

    //     localStorage.setItem("admin-token", result.data.token)

    //     history.push("/dashboard")

    //   })
    //   .catch(error => alert("Could not sign in."))




  }



  return (
    <div className="c-app c-default-layout flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md="8">
            <CCardGroup>
              <CCard className="p-4">
                <CCardBody>
                  <CForm>
                    <h1>Admin Login</h1>
                    <p className="text-muted">Sign In to your account</p>
                    <CInputGroup className="mb-3">
                      <CInputGroupPrepend>
                        <CInputGroupText>
                          <CIcon name="cil-user" />
                        </CInputGroupText>
                      </CInputGroupPrepend>
                      <CInput onChange={(ev) => setValues({ ...values, username: ev.target.value })} type="text" placeholder="Username" autoComplete="username" />
                    </CInputGroup>
                    <CInputGroup className="mb-4">
                      <CInputGroupPrepend>
                        <CInputGroupText>
                          <CIcon name="cil-lock-locked" />
                        </CInputGroupText>
                      </CInputGroupPrepend>
                      <CInput onChange={(ev) => setValues({ ...values, password: ev.target.value })} type="password" placeholder="Password" autoComplete="current-password" />
                    </CInputGroup>
                    <CRow>
                      <CCol xs="6">
                        <CButton onClick={() => submit()} color="primary" className="px-4">Login</CButton>
                      </CCol>

                    </CRow>
                  </CForm>
                </CCardBody>
              </CCard>
              <CCard className="text-white bg-primary py-5 d-md-down-none" style={{ width: '44%' }}>
                <CCardBody className="text-center">
                  <div>
                    <h2>Van Tracking System</h2>
                    <p>Van Tracking System</p>

                  </div>
                </CCardBody>
              </CCard>
            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  )
}

export default Login
