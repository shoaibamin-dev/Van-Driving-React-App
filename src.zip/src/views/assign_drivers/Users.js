import React, { useState, useEffect, useRef } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter
} from '@coreui/react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Col, Row, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

import axios from 'axios';

import { database } from '../../firebase'


// import usersData from './UsersData'

const getBadge = status => {
  switch (status) {
    case 'Active': return 'success'
    case 'Inactive': return 'danger'
    case 'Pending': return 'warning'
    case 'Banned': return 'danger'
    case 'View': return 'primary'
    default: return 'primary'
  }
}

const Add = (props) => {
  const [values, setValues] = props.handles;
  const {
    buttonLabel,
    className,
    addForm,
    modal,
    toggle
  } = props;
  const [children, setChildren] = useState([]);
  const [drivers, setDrivers] = useState([]);

  const getDrivers = async () => {

    const childRef = await database.ref('drivers');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localUsers = Object.entries(snap.val())
      console.log(localUsers)
      setDrivers(localUsers.map(child => child[1]))
    })

  }
  const getChildren = async () => {
    const childRef = await database.ref('children');
    await childRef.once('value', snap => {
      if (!snap.val()) return;
      const localUsers = Object.entries(snap.val())
      console.log(localUsers)
      setChildren(localUsers.map(child => child[1]))
    })
  }

  useEffect(() => {

    getDrivers();
    getChildren();


  }, [])


  return (
    <div>
      <Button style={{ float: 'right' }} color="primary" onClick={toggle}>{buttonLabel}</Button>
      <Modal isOpen={modal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Assign Children To Parent</ModalHeader>
        <ModalBody>

          <Form onSubmit={addForm}>
            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Child ID</Label>
              <Col sm={10}>

                <Input type="select" name="selectChildID" onChange={(ev) => setValues({ ...values, child_id: ev.target.value })}>
                  <option value="">SELECT CHILD ID</option>
                  {children.map((child, idx) => <option key={idx} value={child.id}>{child.id} - {child.name}</option>)}
                </Input>

              </Col>
            </FormGroup>

            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Driver ID</Label>
              <Col sm={10}>

                <Input type="select" name="selectDriverID" onChange={(ev) => setValues({ ...values, driver_id: ev.target.value })}>
                  <option value="">SELECT DRIVER ID</option>
                  {drivers.map((driver, idx) => <option key={idx} value={driver.id}>{driver.id} - {driver.name}</option>)}
                </Input>

              </Col>
            </FormGroup>


            <FormGroup check row>
              <Col sm={{ size: 10, offset: 2 }}>
                <Button color="success" style={{ float: 'right' }}>Submit</Button>
              </Col>
            </FormGroup>
          </Form>

        </ModalBody>
        <ModalFooter>
          {/* <Button color="primary" onClick={toggle}>Do Something</Button>{' '} */}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}



const Users = () => {
  const history = useHistory()
  const queryPage = useLocation().search.match(/page=([0-9]+)/, '')
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1)
  const [page, setPage] = useState(currentPage)
  const [userData, setUserData] = useState([])
  const [editColumn, setEditColumn] = useState('');
  // const [editValues, setEditValues]

  const [values, setValues] = useState({
    parent_id: '', child_id: ''
  });

  const [children, setChildren] = useState([]);
  const [localValues, setLocalValues] = useState('')

  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);


  const pageChange = newPage => {
    currentPage !== newPage && history.push(`/users?page=${newPage}`)
  }

  useEffect(() => {
    currentPage !== page && setPage(currentPage)
  }, [currentPage, page])

  useEffect(() => {

    if (!localStorage.getItem('admin-login')) {
      return history.push('/')
    }

    const childRef = database.ref('driver_child');
    childRef.once('value', snap => {
      if (!snap.val()) return;
      const localChildren = Object.entries(snap.val())
      console.log(localChildren)


      const results = combineData(localChildren);

      results.then(data => setChildren(data))

    })

  }, [])


  const combineData = async (localChildren) => {

    const driverRef = database.ref('drivers');
    const childRef = database.ref('children');

    var results = await Promise.all(localChildren.map(async (child) => {

      let currentChild = { ...child[1] }
      console.log(currentChild.driver_id)

      await driverRef.child(currentChild.driver_id).once('value', snap2 => {
        if (!snap2.val()) return
        console.log("getting name")
        const currentDriver = snap2.val();
        currentChild.driver_name = currentDriver["name"];
        console.log(currentChild.driver_name)

      });

      await childRef.child(currentChild.child_id).once('value', snap2 => {
        if (!snap2.val()) return
        const currentParent = snap2.val();
        currentChild.child_name = currentParent["name"];


      });


      return currentChild;

    }));
    console.log("Results", results)
    return results;

  }

  const getParentIDFromChildID = async (cid) => {
    const parentChildRef = await database.ref('parent_child');
    await parentChildRef.once('value', snap => {
      const snapshot = snap.val();
      for (const attr in snapshot) {
        if (Object.hasOwnProperty.call(snapshot, attr)) {
          const child = snapshot[attr];
          if (child.child_id === cid) {
            setValues({ ...values, parent_id: child.parent_id })
          };
        }
      }
    })
  }

  const addForm = async (ev) => {
    ev.preventDefault();


    await getParentIDFromChildID(values.child_id);
    console.log(values, "after adding parent")
    const childRef = database.ref('driver_child');
    const key = childRef.push().key;
    childRef.child(values.driver_id + "@@" + values.child_id).set({ ...values, id: values.driver_id + "@@" + values.child_id, created_at: new Date().toLocaleString(), is_active: true })
      .then(() => {
        alert('Child assigned to driver successfully.')
        toggle();
      })
      .catch(() => alert('Something went wrong, please try again!'))

  }

  const editForm = () => {


    const childRef = database.ref('driver_child').child(editColumn);
    childRef.update({
      ...localValues
    })
      .then(() => {
        alert('driver_child updated successfully.')
        setChildren(children.map(child => child.id === editColumn ? { ...child, ...localValues } : child))
        setEditColumn('')
        setLocalValues('')
      })
      .catch(error => alert('Something went wrong.'))




  }

  const deleteForm = (id) => {

    const childRef = database.ref('driver_child').child(id);
    childRef.update({
      is_active: false
    })
      .then(() => {
        alert('The selected record is deleted successfully.')
      })
      .catch(error => alert('Something went wrong.'))


  }

  const undeleteForm = (id) => {

    const driverRef = database.ref('driver_child').child(id);
    driverRef.update({
      is_active: true
    })
      .then(() => {
        alert('The selected record is active!')
      })
      .catch(error => alert('Something went wrong.'))


  }


  return (
    <CRow>

      <CCol xl={12}>
        <CCard>
          <CCardHeader>
            Users
            <small className="text-muted"> Van Tracking System</small>
            <Add modal={modal} toggle={toggle} addForm={addForm} buttonLabel='Assign' handles={[values, setValues]} />
          </CCardHeader>
          <CCardBody>
            <CDataTable
              items={children}
              tableFilter
              columnFilter

              fields={[
                { key: 'id', _classes: 'font-weight-bold' },
                'driver_id',
                'driver_name',
                'parent_id',
                'child_id',
                'child_name',
                'created_at', 'is_active',
                'delete'
              ]}
              sorter
              border
              hover
              striped
              itemsPerPage={8}
              activePage={page}
              clickableRows
              column-filter
              table-filter
              scopedSlots={{




                'delete':
                  (item) => (

                    <td>
                      {
                        item.is_active ?
                          <CButton color="danger" onClick={() => {
                            deleteForm(item.id)
                          }}>Delete</CButton>
                          :
                          <CButton color="success" onClick={() => {
                            undeleteForm(item.id)
                          }}>Active</CButton>
                      }

                    </td>
                  ),
                'is_active':
                  (item) => (

                    <td>


                      <b>{item.is_active ? 'Yes' : 'No'}</b>


                    </td>
                  )




              }}
            />
            <CPagination
              activePage={page}
              onActivePageChange={pageChange}
              doubleArrows={true}
              align="center"
            />
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Users
