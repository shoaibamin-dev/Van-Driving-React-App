import React, { useState, useEffect, useRef } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter
} from '@coreui/react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Col, Row, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

import axios from 'axios';

import { database } from '../../firebase'


// import usersData from './UsersData'

const getBadge = status => {
  switch (status) {
    case 'Active': return 'success'
    case 'Inactive': return 'danger'
    case 'Pending': return 'warning'
    case 'Banned': return 'danger'
    case 'View': return 'primary'
    default: return 'primary'
  }
}

const Add = (props) => {
  const [values, setValues] = props.handles;
  const {
    buttonLabel,
    className,
    addForm,
    modal,
    toggle
  } = props;




  return (
    <div>
      <Button style={{ float: 'right' }} color="primary" onClick={toggle}>{buttonLabel}</Button>
      <Modal isOpen={modal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Add Parent</ModalHeader>
        <ModalBody>

          <Form onSubmit={addForm}>
            <FormGroup row>
              <Label for="exampleEmail" sm={2}>Email</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, email: ev.target.value })} type="email" name="email" id="exampleEmail" placeholder="abc@xyz.com" />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="examplePassword" sm={2}>Password</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, password: ev.target.value })} type="password" name="password" id="examplePassword" placeholder="password" />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="exampleName" sm={2}>Name</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, name: ev.target.value })} type="text" name="Name" id="name" placeholder="John Doe" />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="exampleNum" sm={2}>Phone</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, phone: ev.target.value })} type="tel" name="Number" id="number" placeholder="123312313" />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="exampleAddress" sm={2}>Address</Label>
              <Col sm={10}>
                <Input onChange={(ev) => setValues({ ...values, address: ev.target.value })} type="text" name="Address" id="address" placeholder="ABC Street" />
              </Col>
            </FormGroup>
            <Row form>
              <Col md={6}>
                <FormGroup>
                  <Label for="exampleLatitude">Latitude</Label>
                  <Input onChange={(ev) => setValues({ ...values, lat: ev.target.value })} type="latitude" name="latitude" id="exampleLatitude" placeholder="0.123123" />
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="exampleLongitude">Longitude</Label>
                  <Input onChange={(ev) => setValues({ ...values, lng: ev.target.value })} type="longitude" name="longitude" id="exampleLongitude" placeholder="0.123123" />
                </FormGroup>
              </Col>
            </Row>

            <FormGroup check row>
              <Col sm={{ size: 10, offset: 2 }}>
                <Button color="success" style={{ float: 'right' }}>Submit</Button>
              </Col>
            </FormGroup>
          </Form>

        </ModalBody>
        <ModalFooter>
          {/* <Button color="primary" onClick={toggle}>Do Something</Button>{' '} */}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}



const Users = () => {
  const history = useHistory()
  const queryPage = useLocation().search.match(/page=([0-9]+)/, '')
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1)
  const [page, setPage] = useState(currentPage)
  const [userData, setUserData] = useState([])
  const [editColumn, setEditColumn] = useState('');
  // const [editValues, setEditValues]

  const [values, setValues] = useState({ name: '', email: '', password: '', phone: '', address: '', lat: '', lng: '' });

  const [parents, setParents] = useState([]);
  const [localValues, setLocalValues] = useState('')

  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);


  const pageChange = newPage => {
    currentPage !== newPage && history.push(`/users?page=${newPage}`)
  }

  useEffect(() => {
    currentPage !== page && setPage(currentPage)
  }, [currentPage, page])

  useEffect(() => {

    if (!localStorage.getItem('admin-login')) {
      return history.push('/')
    }

    const parentRef = database.ref('parents');
    parentRef.once('value', snap => {
      if (!snap.val()) return;
      const localParents = Object.entries(snap.val())
      setParents(localParents.map(parent => parent[1]))
    })

  }, [])

  const addForm = (ev) => {
    ev.preventDefault();
    console.log(values)

    const parentRef = database.ref('parents');
    const key = parentRef.push().key;
    parentRef.child(key).set({ ...values, id: key, created_at: new Date().toLocaleString(), is_active: true })
      .then(() => {
        alert('Parent added successfully')
        toggle();

      })
      .catch(() => alert('Something went wrong, please try again!'))

  }

  const editForm = () => {


    const parentRef = database.ref('parents').child(editColumn);
    parentRef.update({
      ...localValues
    })
      .then(() => {
        alert('parent updated successfully.')
        setParents(parents.map(parent => parent.id === editColumn ? { ...parent, ...localValues } : parent))
        setEditColumn('')
        setLocalValues('')
      })
      .catch(error => alert('Something went wrong.'))




  }

  const deleteForm = (id) => {

    const parentRef = database.ref('parents').child(id);
    parentRef.update({
      is_active: false
    })
      .then(() => {
        alert('parent deleted successfully.')
      })
      .catch(error => alert('Something went wrong.'))


  }


  const undeleteForm = (id) => {

    const driverRef = database.ref('parents').child(id);
    driverRef.update({
      is_active: true
    })
      .then(() => {
        alert('Parent is active.')
      })
      .catch(error => alert('Something went wrong.'))


  }

  return (
    <CRow>

      <CCol xl={12}>
        <CCard>
          <CCardHeader>
            Users
            <small className="text-muted"> Van Tracking System</small>
            <Add modal={modal} toggle={toggle} addForm={addForm} buttonLabel='Add' handles={[values, setValues]} />
          </CCardHeader>
          <CCardBody>
            <CDataTable
              items={parents}
              tableFilter
              columnFilter

              fields={[
                'id',
                { key: 'name', _classes: 'font-weight-bold' },
                'email', 'password',
                'phone',
                'address',
                'lat', 'lng',
                'created_at', 'is_active',
                'edit', 'delete'
              ]}
              sorter
              border
              hover
              striped
              itemsPerPage={8}
              activePage={page}
              clickableRows
              column-filter
              table-filter
              scopedSlots={{



                'name':
                  (item) => (

                    <td style={{ minWidth: '150px', fontWeight: 'bold' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.name
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, name: ev.target.value })}
                          value={localValues.name}
                          type="text" name="Name" placeholder="John Doe" />

                      }

                    </td>
                  ),
                'email':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.email
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, email: ev.target.value })}
                          value={localValues.email}
                          type="email" name="Email" placeholder="abc@xyz.com" />

                      }

                    </td>
                  ),
                'password':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {

                        (editColumn !== item.id)
                        &&
                        item.password
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, password: ev.target.value })}
                          value={localValues.password}
                          type="text" name="Password" placeholder="password" />

                      }

                    </td>
                  ),

                'phone':
                  (item) => (

                    <td style={{ minWidth: '150px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.phone
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, phone: ev.target.value })}
                          value={localValues.phone}
                          type="tel" name="Phone" placeholder="012312312" />

                      }

                    </td>
                  ),

                'address':
                  (item) => (

                    <td style={{ minWidth: '250px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.address
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, address: ev.target.value })}
                          value={localValues.address}
                          type="text" name="Address" placeholder="ABC St" />

                      }

                    </td>
                  ),



                'lat':
                  (item) => (

                    <td style={{ minWidth: '100px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.lat
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, lat: ev.target.value })}
                          value={localValues.lat}
                          type="text" name="Latitude" placeholder="0.2332" />

                      }

                    </td>
                  ),

                'lng':
                  (item) => (

                    <td style={{ minWidth: '100px' }}>

                      {
                        (editColumn !== item.id)
                        &&
                        item.lng
                        ||
                        <Input
                          onChange={ev => setLocalValues({ ...localValues, lng: ev.target.value })}
                          value={localValues.lng}
                          type="text" name="Longitude" placeholder="0.2332" />

                      }

                    </td>
                  ),

                'edit':
                  (item) => (

                    <td>

                      {(editColumn !== item.id)
                        &&
                        <CButton color="primary" onClick={() => {
                          setEditColumn(item.id)
                          setLocalValues({ ...item })
                        }
                        }>
                          Edit
                        </CButton>
                        ||
                        <CButton color="success" onClick={() => {
                          editForm();
                        }}>
                          Done
                        </CButton>
                      }

                    </td>
                  ),

                'delete':
                  (item) => (

                    <td>
                      {
                        item.is_active ?
                          <CButton color="danger" onClick={() => {
                            deleteForm(item.id)
                          }}>Delete</CButton>
                          :
                          <CButton color="success" onClick={() => {
                            undeleteForm(item.id)
                          }}>Active</CButton>
                      }

                    </td>
                  ),
                'is_active':
                  (item) => (

                    <td>


                      <b>{item.is_active ? 'Yes' : 'No'}</b>


                    </td>
                  )




              }}
            />
            <CPagination
              activePage={page}
              onActivePageChange={pageChange}
              doubleArrows={true}
              align="center"
            />
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Users
