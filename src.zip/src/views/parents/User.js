import React, { useEffect, useState } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import { CCard, CCardBody, CCardHeader, CCol, CRow } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import axios from 'axios';


const User = ({ match, location }) => {
  const history = useHistory()

  // console.log(location.state)

  // const user = [].find(user => user.id.toString() === match.params.id)
  // const userDetails = location.state ? Object.entries(location.state) :
  //   [['id', (<span><CIcon className="text-muted" name="cui-icon-ban" /> Not found</span>)]]

  const [userDetails, setUserDetails] = useState([]);
  const [eventDetails, setEventDetails] = useState([]);

  const getUserData = () => {

    try {
      const user_details = Object.entries(location.state)
      console.log(user_details.length)
      user_details.forEach(user => console.log(user));

      setUserDetails(user_details);
    }
    catch (error) {
      history.push(`/users`)
    }

  }

  const getEventData = () => {
    const eventRequest = axios({
      method: 'get',
      url: '/api/event/self/one/' + match.params.id,
      headers: {
        Authorization: 'Bearer ' + localStorage.getItem("admin-token")
      }
    })


    axios.all([eventRequest]).then(axios.spread((...responses) => {

      const eventResponse = responses[0].data.data.map(event => {
        return Object.entries(event)
      })
      console.log("after cleaning", eventResponse)
      setEventDetails(eventResponse)

    })).catch(errors => {
      alert("something went wrong, please try again!")
    })


  }

  useEffect(() => {

    getUserData();

  }, [])

  useEffect(() => {

    //getEventData();

  }, [])



  return (
    <CRow>
      <CCol lg={12}>
        <CCard>
          <CCardHeader>
            <center>User ID: <b>{match.params.id}</b></center>
          </CCardHeader>
          <CCardBody>

            <div className="profile-container">
              <h1>Profile, Role, and Status</h1>
              <table className="table table-striped table-bordered  table-hover">
                <tbody>

                  {

                    userDetails.map((row, idx) => {

                      return idx != userDetails.length - 1 && <tr key={idx}>
                        <td><i>{row[0].toUpperCase()}</i></td>
                        <td>
                          {
                            row[0].toLowerCase() === "image"
                              ?
                              <a target="_blank" href={row[1]}><img height="100" width="100" src={row[1]} /></a>
                              :
                              <b>{row[1]}</b>
                          }


                        </td>
                      </tr>
                    })

                  }
                </tbody>
              </table>
            </div>

            <div className="events-container my-2">
              {/* <h1>Events</h1> */}
              <table className="table table-striped table-bordered  table-hover">
                <tbody>

                  {

                    eventDetails.map((event, idx) => {

                      return event.map((detail, idxx) => {

                        return <tr className={idxx === 0 && "black-separator" || ""} key={idxx}>

                          <td><i>{detail[0].toUpperCase()}</i></td>
                          <td>
                            {
                              detail[0].toLowerCase() === "image_url"
                                ?
                                <a target="_blank" href={detail[1]}><img height="100" width="100" src={detail[1]} /></a>
                                :
                                <b>{JSON.stringify(detail[1]).replaceAll('"', '')}</b>
                            }


                          </td>
                        </tr>

                      })



                    })

                  }


                </tbody>
              </table>
            </div>





          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default User
