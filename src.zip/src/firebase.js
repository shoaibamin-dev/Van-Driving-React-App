import firebase from "firebase/app"
import "firebase/auth"
import "firebase/database"

const app = firebase.initializeApp({
    apiKey: "AIzaSyBCqTM4T4BlcpNtgIliAhLtFx2LuKlzRCI",
    authDomain: "van-tracking-app-cf891.firebaseapp.com",
    projectId: "van-tracking-app-cf891",
    storageBucket: "van-tracking-app-cf891.appspot.com",
    messagingSenderId: "392204471812",
    appId: "1:392204471812:web:131dfab59d23c9a8972f51"
})

export const auth = app.auth()
export const database = app.database()
export default app