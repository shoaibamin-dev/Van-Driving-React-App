import React from 'react';

// const Toaster = React.lazy(() => import('./views/notifications/toaster/Toaster'));
const Tables = React.lazy(() => import('./views/base/tables/Tables'));

const Breadcrumbs = React.lazy(() => import('./views/base/breadcrumbs/Breadcrumbs'));
const Cards = React.lazy(() => import('./views/base/cards/Cards'));
const Carousels = React.lazy(() => import('./views/base/carousels/Carousels'));
const Collapses = React.lazy(() => import('./views/base/collapses/Collapses'));
const BasicForms = React.lazy(() => import('./views/base/forms/BasicForms'));

const Jumbotrons = React.lazy(() => import('./views/base/jumbotrons/Jumbotrons'));
const ListGroups = React.lazy(() => import('./views/base/list-groups/ListGroups'));
const Navbars = React.lazy(() => import('./views/base/navbars/Navbars'));
const Navs = React.lazy(() => import('./views/base/navs/Navs'));
const Paginations = React.lazy(() => import('./views/base/paginations/Pagnations'));
const Popovers = React.lazy(() => import('./views/base/popovers/Popovers'));
const ProgressBar = React.lazy(() => import('./views/base/progress-bar/ProgressBar'));
const Switches = React.lazy(() => import('./views/base/switches/Switches'));

const Tabs = React.lazy(() => import('./views/base/tabs/Tabs'));
const Tooltips = React.lazy(() => import('./views/base/tooltips/Tooltips'));
const BrandButtons = React.lazy(() => import('./views/buttons/brand-buttons/BrandButtons'));
const ButtonDropdowns = React.lazy(() => import('./views/buttons/button-dropdowns/ButtonDropdowns'));
const ButtonGroups = React.lazy(() => import('./views/buttons/button-groups/ButtonGroups'));
const Buttons = React.lazy(() => import('./views/buttons/buttons/Buttons'));
const Charts = React.lazy(() => import('./views/charts/Charts'));
const Dashboard = React.lazy(() => import('./views/dashboard/Dashboard'));
const CoreUIIcons = React.lazy(() => import('./views/icons/coreui-icons/CoreUIIcons'));
const Flags = React.lazy(() => import('./views/icons/flags/Flags'));
const Brands = React.lazy(() => import('./views/icons/brands/Brands'));
// const Alerts = React.lazy(() => import('./views/notifications/alerts/Alerts'));
// const Badges = React.lazy(() => import('./views/notifications/badges/Badges'));
// const Modals = React.lazy(() => import('./views/notifications/modals/Modals'));
const Colors = React.lazy(() => import('./views/theme/colors/Colors'));
const Typography = React.lazy(() => import('./views/theme/typography/Typography'));
const Widgets = React.lazy(() => import('./views/widgets/Widgets'));

const Login = React.lazy(() => import('./views/pages/login/Login'));


// DRIVERS
const Drivers = React.lazy(() => import('./views/drivers/Users'));
const Driver = React.lazy(() => import('./views/drivers/User'));


// PARENTS
const Parents = React.lazy(() => import('./views/parents/Users'));
const Parent = React.lazy(() => import('./views/parents/User'));


// CHILDREN
const Children = React.lazy(() => import('./views/children/Users'));
const Child = React.lazy(() => import('./views/children/User'));

// ASSIGN CHILD
const AssignChildren = React.lazy(() => import('./views/assign_children/Users'));
const AssignChild = React.lazy(() => import('./views/assign_children/User'));


// ASSIGN DRIVER
const AssignDrivers = React.lazy(() => import('./views/assign_drivers/Users'));
const AssignDriver = React.lazy(() => import('./views/assign_drivers/User'));

// FEE LOG
const FeeLogs = React.lazy(() => import('./views/fee_logs/Users'));
const FeeLog = React.lazy(() => import('./views/fee_logs/User'));


// DRIVER PARENT LOG
const DriverParentLogs = React.lazy(() => import('./views/driver_parent_logs/Users'));
const DriverParentLog = React.lazy(() => import('./views/driver_parent_logs/User'));

// NOTIFICATION EVENT LOG
const NotificationEventLogs = React.lazy(() => import('./views/notification_event_logs/Users'));
const NotificationEventLog = React.lazy(() => import('./views/notification_event_logs/User'));

// DRIVER ADMIN LOG
const DriverAdminLogs = React.lazy(() => import('./views/driver_admin_logs/Users'));
const DriverAdminLog = React.lazy(() => import('./views/driver_admin_logs/User'));


// DRIVER LOCATION
const DriverLocations = React.lazy(() => import('./views/driver_locations/Users'));
const DriverLocation = React.lazy(() => import('./views/driver_locations/User'));




// // FEEDS
// const Feed = React.lazy(() => import('./views/feeds/Feed'));
// const Feeds = React.lazy(() => import('./views/feeds/Feeds'));

// // EVENTS
// const Event = React.lazy(() => import('./views/events/Event'));
// const Events = React.lazy(() => import('./views/events/Events'));

// // JOBS
// const Job = React.lazy(() => import('./views/jobs/Job'));
// const Jobs = React.lazy(() => import('./views/jobs/Jobs'));

// // CHATS
// const Chat = React.lazy(() => import('./views/chats/Chat'));
// const Chats = React.lazy(() => import('./views/chats/Chats'));


// // CONNECTS
// const Connect = React.lazy(() => import('./views/connects/Connect'));
// const Connects = React.lazy(() => import('./views/connects/Connects'));


// TASKS
// const Task = React.lazy(() => import('./views/tasks/Task'));
// const Tasks = React.lazy(() => import('./views/tasks/Tasks'));



const routes = [
  // { path: '/', exact: true, name: 'Login', component: Login },
  { path: '/', name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/theme', name: 'Theme', component: Colors, exact: true },
  { path: '/theme/colors', name: 'Colors', component: Colors },
  { path: '/theme/typography', name: 'Typography', component: Typography },
  { path: '/base', name: 'Base', component: Cards, exact: true },
  { path: '/base/breadcrumbs', name: 'Breadcrumbs', component: Breadcrumbs },
  { path: '/base/cards', name: 'Cards', component: Cards },
  { path: '/base/carousels', name: 'Carousel', component: Carousels },
  { path: '/base/collapses', name: 'Collapse', component: Collapses },
  { path: '/base/forms', name: 'Forms', component: BasicForms },
  { path: '/base/jumbotrons', name: 'Jumbotrons', component: Jumbotrons },
  { path: '/base/list-groups', name: 'List Groups', component: ListGroups },
  { path: '/base/navbars', name: 'Navbars', component: Navbars },
  { path: '/base/navs', name: 'Navs', component: Navs },
  { path: '/base/paginations', name: 'Paginations', component: Paginations },
  { path: '/base/popovers', name: 'Popovers', component: Popovers },
  { path: '/base/progress-bar', name: 'Progress Bar', component: ProgressBar },
  { path: '/base/switches', name: 'Switches', component: Switches },
  { path: '/base/tables', name: 'Tables', component: Tables },
  { path: '/base/tabs', name: 'Tabs', component: Tabs },
  { path: '/base/tooltips', name: 'Tooltips', component: Tooltips },
  { path: '/buttons', name: 'Buttons', component: Buttons, exact: true },
  { path: '/buttons/buttons', name: 'Buttons', component: Buttons },
  { path: '/buttons/button-dropdowns', name: 'Dropdowns', component: ButtonDropdowns },
  { path: '/buttons/button-groups', name: 'Button Groups', component: ButtonGroups },
  { path: '/buttons/brand-buttons', name: 'Brand Buttons', component: BrandButtons },
  { path: '/charts', name: 'Charts', component: Charts },
  { path: '/icons', exact: true, name: 'Icons', component: CoreUIIcons },
  { path: '/icons/coreui-icons', name: 'CoreUI Icons', component: CoreUIIcons },
  { path: '/icons/flags', name: 'Flags', component: Flags },
  { path: '/icons/brands', name: 'Brands', component: Brands },
  // { path: '/notifications', name: 'Notifications', component: Alerts, exact: true },
  // { path: '/notifications/alerts', name: 'Alerts', component: Alerts },
  // { path: '/notifications/badges', name: 'Badges', component: Badges },
  // { path: '/notifications/modals', name: 'Modals', component: Modals },
  // { path: '/notifications/toaster', name: 'Toaster', component: Toaster },
  { path: '/widgets', name: 'Widgets', component: Widgets },

  // DRIVERS
  { path: '/drivers', exact: true, name: 'Drivers', component: Drivers },
  { path: '/drivers/:id', exact: true, name: 'Driver Details', component: Driver },

  // PARENTS
  { path: '/parents', exact: true, name: 'Parents', component: Parents },
  { path: '/parents/:id', exact: true, name: 'Parents Details', component: Parent },

  // CHILDREN
  { path: '/children', exact: true, name: 'Children', component: Children },
  { path: '/children/:id', exact: true, name: 'Children Details', component: Child },


  // ASSIGN CHILD TO PARENT
  { path: '/assign_children', exact: true, name: 'Assign Child', component: AssignChildren },
  { path: '/assign_children/:id', exact: true, name: 'Assign Child Details', component: AssignChild },


  // ASSIGN DRIVER TO CHILD
  { path: '/assign_drivers', exact: true, name: 'Assign Driver', component: AssignDrivers },
  { path: '/assign_drivers/:id', exact: true, name: 'Assign Driver Details', component: AssignDriver },


  // FEE LOGS
  { path: '/fee_logs', exact: true, name: 'Assign Child', component: FeeLogs },
  { path: '/fee_logs/:id', exact: true, name: 'Assign Child Details', component: FeeLog },


  // DRIVER PARENT LOGS
  { path: '/driver_parent_logs', exact: true, name: 'Emergency SMS Log', component: DriverParentLogs },
  { path: '/driver_parent_logs/:id', exact: true, name: 'Emergency SMS Log Details', component: DriverParentLog },

  // NOTIFICATION EVENT LOGS
  { path: '/notification_event_logs', exact: true, name: 'Notification Event Log', component: NotificationEventLogs },
  { path: '/notification_event_logs/:id', exact: true, name: 'Notification Event Log Details', component: NotificationEventLog },

  // DRIVER LOCATIONS
  { path: '/driver_locations', exact: true, name: 'Driver Locations', component: DriverLocations },
  { path: '/driver_locations/:id', exact: true, name: 'Driver Locations Details', component: DriverLocation },

  // DRIVER ADMIN LOGS
  { path: '/driver_admin_logs', exact: true, name: 'Driver Admin Logs', component: DriverAdminLogs },
  { path: '/driver_admin_logs/:id', exact: true, name: 'Driver Admin Logs Details', component: DriverAdminLog },



  // // FEEDS
  // { path: '/feeds', exact: true, name: 'Feeds', component: Feeds },
  // { path: '/feeds/:id', exact: true, name: 'Feeds Details', component: Feed },

  // // EVENTS
  // { path: '/events', exact: true, name: 'Events', component: Events },
  // { path: '/events/:id', exact: true, name: 'Events Details', component: Event },

  // // JOBS
  // { path: '/jobs', exact: true, name: 'Jobs', component: Jobs },
  // { path: '/jobs/:id', exact: true, name: 'Jobs Details', component: Job },


  // // CHATS
  // { path: '/chats', exact: true, name: 'Chats', component: Chats },
  // { path: '/chats/:id', exact: true, name: 'Chats Details', component: Chat },



  // // CONNECTS
  // { path: '/connects', exact: true, name: 'Connects', component: Connects },
  // { path: '/connects/:id', exact: true, name: 'Connects Details', component: Connect },


  // // TASKS
  // { path: '/tasks', exact: true, name: 'Tasks', component: Tasks },
  // { path: '/tasks/:id', exact: true, name: 'Tasks Details', component: Task },




];

export default routes;
